<?php

header("Content-Type: application/json");

include "config.php";

$id        = $_POST['id'] ?? '';
$judul     = $_POST['judul'] ?? '';
$nominal   = $_POST['nominal'] ?? '';
$kategori  = $_POST['kategori'] ?? '';
$tanggal   = $_POST['tanggal'] ?? '';

if(
    empty($id) ||
    empty($judul) ||
    empty($nominal) ||
    empty($kategori) ||
    empty($tanggal)
){
    echo json_encode([
        "success"=>false,
        "message"=>"Semua data wajib diisi"
    ]);
    exit;
}

$stmt = $conn->prepare("UPDATE expenses SET judul=?, nominal=?, kategori=?, tanggal=? WHERE id=?");
$stmt->bind_param("sissi",$judul,$nominal,$kategori,$tanggal,$id);

if($stmt->execute()){

    echo json_encode([
        "success"=>true,
        "message"=>"Data berhasil diupdate"
    ]);

}else{

    echo json_encode([
        "success"=>false,
        "message"=>"Gagal update"
    ]);

}

$stmt->close();
$conn->close();

?>