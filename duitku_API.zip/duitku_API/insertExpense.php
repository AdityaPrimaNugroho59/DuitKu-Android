<?php

header("Content-Type: application/json");

include "config.php";

$user_id  = $_POST['user_id'] ?? '';
$judul    = $_POST['judul'] ?? '';
$nominal  = $_POST['nominal'] ?? '';
$kategori = $_POST['kategori'] ?? '';
$tanggal  = $_POST['tanggal'] ?? '';

if (
    empty($user_id) ||
    empty($judul) ||
    empty($nominal) ||
    empty($kategori) ||
    empty($tanggal)
) {
    echo json_encode([
        "success" => false,
        "message" => "Semua data wajib diisi"
    ]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO expenses(user_id,judul,nominal,kategori,tanggal) VALUES(?,?,?,?,?)");

$stmt->bind_param(
    "isiss",
    $user_id,
    $judul,
    $nominal,
    $kategori,
    $tanggal
);

if($stmt->execute()){

    echo json_encode([
        "success"=>true,
        "message"=>"Data berhasil ditambahkan"
    ]);

}else{

    echo json_encode([
        "success"=>false,
        "message"=>"Gagal menambahkan data"
    ]);

}

$stmt->close();
$conn->close();

?>