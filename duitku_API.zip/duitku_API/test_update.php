<?php

$_POST['id']=1;
$_POST['judul']="Makan Siang";
$_POST['nominal']=30000;
$_POST['kategori']="Makanan";
$_POST['tanggal']="2026-07-01";

include "updateExpense.php";

?>
