<?php

header("Content-Type: application/json");

include "config.php";

$user_id = $_GET['user_id'] ?? '';

if(empty($user_id)){
    echo json_encode([
        "success"=>false,
        "message"=>"User ID kosong"
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM expenses WHERE user_id=? ORDER BY id DESC");
$stmt->bind_param("i",$user_id);
$stmt->execute();

$result = $stmt->get_result();

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode([
    "success"=>true,
    "data"=>$data
]);

$stmt->close();
$conn->close();

?>