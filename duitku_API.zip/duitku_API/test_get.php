<?php

$_GET['user_id']=1;

include "getExpense.php";

?>