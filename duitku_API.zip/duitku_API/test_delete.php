<?php

$_POST['id']=1;

include "deleteExpense.php";

?>