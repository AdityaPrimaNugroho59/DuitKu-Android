<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

include "config.php";

$email = $_POST['email'] ?? "";
$password = $_POST['password'] ?? "";

if ($email == "" || $password == "") {
    echo json_encode([
        "success" => false,
        "message" => "Email dan Password wajib diisi"
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT id,nama,email,password FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();

$stmt->bind_result($id, $nama, $emailDb, $passwordHash);

if ($stmt->fetch()) {

    if (password_verify($password, $passwordHash)) {

        echo json_encode([
            "success" => true,
            "message" => "Login berhasil",
            "user" => [
                "id" => $id,
                "nama" => $nama,
                "email" => $emailDb
            ]
        ]);

    } else {

        echo json_encode([
            "success" => false,
            "message" => "Password salah"
        ]);

    }

} else {

    echo json_encode([
        "success" => false,
        "message" => "Email tidak ditemukan"
    ]);

}

$stmt->close();
$conn->close();

?>