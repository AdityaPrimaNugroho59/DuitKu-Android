<?php

header("Content-Type: application/json");

include "config.php";

$nama = isset($_POST['nama']) ? trim($_POST['nama']) : "";
$email = isset($_POST['email']) ? trim($_POST['email']) : "";
$password = isset($_POST['password']) ? trim($_POST['password']) : "";

if($nama=="" || $email=="" || $password==""){

    echo json_encode([
        "success"=>false,
        "message"=>"Semua data wajib diisi"
    ]);

    exit;
}

// cek email
$cek = $conn->prepare("SELECT id FROM users WHERE email=?");
$cek->bind_param("s",$email);
$cek->execute();
$cek->store_result();

if($cek->num_rows>0){

    echo json_encode([
        "success"=>false,
        "message"=>"Email sudah terdaftar"
    ]);

    exit;
}

$passwordHash = password_hash($password,PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users(nama,email,password) VALUES(?,?,?)");

$stmt->bind_param("sss",$nama,$email,$passwordHash);

if($stmt->execute()){

    echo json_encode([
        "success"=>true,
        "message"=>"Register berhasil"
    ]);

}else{

    echo json_encode([
        "success"=>false,
        "message"=>"Register gagal"
    ]);

}

?>