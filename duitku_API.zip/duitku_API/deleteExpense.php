<?php

header("Content-Type: application/json");

include "config.php";

$id=$_POST['id'] ?? '';

if(empty($id)){

    echo json_encode([
        "success"=>false,
        "message"=>"ID kosong"
    ]);

    exit;
}

$stmt=$conn->prepare("DELETE FROM expenses WHERE id=?");
$stmt->bind_param("i",$id);

if($stmt->execute()){

    echo json_encode([
        "success"=>true,
        "message"=>"Data berhasil dihapus"
    ]);

}else{

    echo json_encode([
        "success"=>false,
        "message"=>"Gagal menghapus"
    ]);

}

$stmt->close();
$conn->close();

?>