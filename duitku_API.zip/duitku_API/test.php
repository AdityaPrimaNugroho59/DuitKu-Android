<?php

include "config.php";

echo "Koneksi Database Berhasil";