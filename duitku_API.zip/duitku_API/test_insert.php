<?php

$_POST['user_id']=1;
$_POST['judul']="Makan";
$_POST['nominal']=25000;
$_POST['kategori']="Makanan";
$_POST['tanggal']="2026-06-30";

include "insertExpense.php";

?>